namespace Uwu.Games.Reversi.Student;

using System.Collections.Generic;
using ReversiBehavior = GamePlaying.Behavior<State, Player, Move, Player, int>;
public class Minimax : ReversiBehavior
{
    public Minimax() { }

    // Starts look-ahead process to find best move.
    public Move Run(State board, int lookAheadDepth) => GetBestMove(board, lookAheadDepth);

    // Uses look ahead to evaluate all valid moves for given player color & returns best move
    // found. This method will only be called if there's at least one valid move for player.
    private Move GetBestMove(State board, int depth)
    {
        var maxPlayer = board.Current;
        var moves = GetValidMoves(board, maxPlayer);

        int bestScore = 0;
        Move bestMove = moves[0];

        foreach (var move in moves)
        {
            var next = new State(board);
            next.MakeMove(move);
            next.EndMove();

            int score = MinimaxScore(next, depth - 1, maxPlayer);
            if (score > bestScore)
            {
                bestScore = score;
                bestMove = move;
            }
        }

        return bestMove;
    }

    #region Recommended Helper Functions
    // Evaluate state from the perspective of maxPlayer (the player who started the search).
    private int Evaluate(State board, Player maxPlayer)
    {
        int potentialScore = board.Score;
        if (maxPlayer == Player.Black)
            potentialScore = -potentialScore;

        Player minPlayer = maxPlayer == Player.Black ? Player.White : Player.Black;
        int mobility = board.GetValidMoveCount(maxPlayer) - board.GetValidMoveCount(minPlayer);

        return (potentialScore * 10) + mobility;
    }

    private int MinimaxScore(State board, int depth, Player maxPlayer)
    {
        if (depth <= 0 || board.IsTerminalState())
            return Evaluate(board, maxPlayer);

        var moves = GetValidMoves(board, board.Current);

        if (moves.Count == 0)
        {
            if (board.IsTerminalState())
                return Evaluate(board, maxPlayer);

            var passed = new State(board);
            passed.EndMove();
            return MinimaxScore(passed, depth - 1, maxPlayer);
        }

        if (board.Current == maxPlayer)
        {
            int best = int.MinValue;
            foreach (var move in moves)
            {
                var next = new State(board);
                next.MakeMove(move);
                next.EndMove();
                int score = MinimaxScore(next, depth - 1, maxPlayer);
                if (score > best)
                    best = score;
            }
            return best;
        }
        else
        {
            int best = int.MaxValue;
            foreach (var move in moves)
            {
                var next = new State(board);
                next.MakeMove(move);
                next.EndMove();
                int score = MinimaxScore(next, depth - 1, maxPlayer);
                if (score < best)
                    best = score;
            }
            return best;
        }
    }

    private static List<Move> GetValidMoves(State board, Player player)
    {
        var moves = new List<Move>();
        for (int r = 0; r < State.GRID_SIZE; r++)
        {
            for (int c = 0; c < State.GRID_SIZE; c++)
            {
                var m = State.NewMove(r, c);
                if (board.IsValidMove(player, m))
                    moves.Add(m);
            }
        }
        return moves;
    }

    #endregion
}
